
# This is an R script, where we will practice running 
#   R code without using an RMarkdown document.

# What you need to do here, is to run all the code form the 
#   W04-00 Simple regression slides in here as the R code


# Setup


# Data loading


# Scatter plot


# Simple linear regression


# Regression summary: summary


# Regression summary: broom


# Regression summary: performance and parameters


# Residuals vs Fitter plot

